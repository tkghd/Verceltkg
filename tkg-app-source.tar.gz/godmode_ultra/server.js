const express = require('express');
const app = express();
const PORT = 3000;

// ミドルウェア
app.use(express.json());
app.use(express.static(__dirname));

// レート制限
const requestCounts = new Map();
setInterval(() => requestCounts.clear(), 60000);

// セキュリティヘッダー
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  
  const ip = req.ip;
  const count = requestCounts.get(ip) || 0;
  if (count > 100) {
    return res.status(429).json({ error: 'Too many requests' });
  }
  requestCounts.set(ip, count + 1);
  next();
});

// データストア
const accounts = new Map();
const transactions = [];
const vaults = {
  tokyo: { gold: 5000, silver: 10000, cash: 50000000, location: 'Tokyo, Japan' },
  newyork: { gold: 7000, silver: 15000, cash: 80000000, location: 'New York, USA' },
  london: { gold: 6000, silver: 12000, cash: 70000000, location: 'London, UK' },
  singapore: { gold: 4000, silver: 8000, cash: 40000000, location: 'Singapore' },
  dubai: { gold: 3000, silver: 6000, cash: 30000000, location: 'Dubai, UAE' }
};

// 初期アカウント生成
for (let i = 1; i <= 100; i++) {
  accounts.set(`ACC${i.toString().padStart(6, '0')}`, {
    balance: Math.floor(Math.random() * 1000000),
    currency: 'USD',
    status: 'active',
    created: new Date().toISOString()
  });
}

// ヘルスチェック
app.get('/health', (req, res) => {
  res.json({
    status: 'online',
    service: 'godmode_ultra',
    version: '2.0.0',
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    accounts: accounts.size,
    transactions: transactions.length,
    timestamp: new Date().toISOString()
  });
});

// メインダッシュボード
app.get('/', (req, res) => {
  const totalCash = Object.values(vaults).reduce((sum, v) => sum + v.cash, 0);
  const totalGold = Object.values(vaults).reduce((sum, v) => sum + v.gold, 0);
  const totalSilver = Object.values(vaults).reduce((sum, v) => sum + v.silver, 0);
  
  res.send(`<!DOCTYPE html>
<html>
<head>
  <title>TK Global Bank - Ultra Dashboard</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      padding: 20px;
    }
    .container { max-width: 1400px; margin: 0 auto; }
    .header {
      background: rgba(255,255,255,0.95);
      padding: 30px;
      border-radius: 20px;
      margin-bottom: 30px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.2);
    }
    h1 {
      font-size: 2.5em;
      background: linear-gradient(135deg, #667eea, #764ba2);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 10px;
    }
    .status {
      display: inline-block;
      padding: 8px 20px;
      background: #48bb78;
      color: white;
      border-radius: 20px;
      font-weight: bold;
      animation: pulse 2s infinite;
    }
    @keyframes pulse {
      0%, 100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.9; transform: scale(1.05); }
    }
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 20px;
      margin-bottom: 20px;
    }
    .card {
      background: rgba(255,255,255,0.95);
      padding: 25px;
      border-radius: 15px;
      box-shadow: 0 8px 30px rgba(0,0,0,0.15);
      transition: transform 0.3s;
    }
    .card:hover { transform: translateY(-5px); }
    .card-title {
      font-size: 1.2em;
      color: #2d3748;
      margin-bottom: 15px;
      font-weight: 600;
    }
    .stat {
      font-size: 2.5em;
      font-weight: bold;
      background: linear-gradient(135deg, #667eea, #764ba2);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin: 10px 0;
    }
    .label { color: #718096; font-size: 0.9em; }
    .metric {
      display: flex;
      justify-content: space-between;
      padding: 10px 0;
      border-bottom: 1px solid #e2e8f0;
    }
    .metric:last-child { border-bottom: none; }
    .btn {
      display: inline-block;
      padding: 12px 30px;
      background: linear-gradient(135deg, #667eea, #764ba2);
      color: white;
      text-decoration: none;
      border-radius: 25px;
      font-weight: bold;
      transition: transform 0.2s;
    }
    .btn:hover { transform: scale(1.05); }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🏦 TK Global Bank - Godmode Ultra</h1>
      <span class="status">● OPERATIONAL</span>
      <p style="margin-top: 10px; color: #718096;">Enterprise Banking System v2.0</p>
    </div>
    
    <div class="grid">
      <div class="card">
        <div class="card-title">💰 Total Assets</div>
        <div class="stat">$${(totalCash / 1000000).toFixed(1)}M</div>
        <div class="label">Global Cash Reserves</div>
      </div>
      
      <div class="card">
        <div class="card-title">🏅 Precious Metals</div>
        <div class="metric"><span>Gold</span><span>${totalGold.toLocaleString()} oz</span></div>
        <div class="metric"><span>Silver</span><span>${totalSilver.toLocaleString()} oz</span></div>
      </div>
      
      <div class="card">
        <div class="card-title">👥 Active Accounts</div>
        <div class="stat">${accounts.size}</div>
        <div class="label">Customer Accounts</div>
      </div>
      
      <div class="card">
        <div class="card-title">📊 System Status</div>
        <div class="metric"><span>Uptime</span><span>${Math.floor(process.uptime() / 60)}m</span></div>
        <div class="metric"><span>Transactions</span><span>${transactions.length}</span></div>
        <div class="metric"><span>API Status</span><span style="color:#48bb78">✓ Online</span></div>
      </div>
    </div>
    
    <div class="grid">
      ${Object.entries(vaults).map(([key, vault]) => `
        <div class="card">
          <div class="card-title">🏛️ ${vault.location}</div>
          <div class="metric"><span>Cash</span><span>$${(vault.cash / 1000000).toFixed(1)}M</span></div>
          <div class="metric"><span>Gold</span><span>${vault.gold} oz</span></div>
          <div class="metric"><span>Silver</span><span>${vault.silver} oz</span></div>
        </div>
      `).join('')}
    </div>
    
    <div style="text-align: center; margin-top: 30px;">
      <a href="/api/accounts" class="btn">📋 View All Accounts</a>
      <a href="/health" class="btn">🔧 System Health</a>
    </div>
  </div>
  
  <script>
    setInterval(() => {
      fetch('/health')
        .then(r => r.json())
        .then(data => console.log('System Status:', data));
    }, 30000);
  </script>
</body>
</html>`);
});

// API エンドポイント
app.get('/api/accounts', (req, res) => {
  const accountList = Array.from(accounts.entries()).map(([id, data]) => ({
    id,
    ...data
  }));
  res.json({ total: accountList.length, accounts: accountList });
});

app.get('/api/account/:id', (req, res) => {
  const account = accounts.get(req.params.id);
  if (!account) return res.status(404).json({ error: 'Account not found' });
  res.json({ id: req.params.id, ...account });
});

app.get('/api/vaults', (req, res) => {
  res.json(vaults);
});

app.get('/api/vault/:location', (req, res) => {
  const vault = vaults[req.params.location];
  if (!vault) return res.status(404).json({ error: 'Vault not found' });
  res.json({ location: req.params.location, ...vault });
});

app.post('/api/transfer', (req, res) => {
  const { from, to, amount } = req.body;
  
  if (!from || !to || !amount) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  
  const fromAccount = accounts.get(from);
  const toAccount = accounts.get(to);
  
  if (!fromAccount || !toAccount) {
    return res.status(404).json({ error: 'Account not found' });
  }
  
  if (fromAccount.balance < amount) {
    return res.status(400).json({ error: 'Insufficient funds' });
  }
  
  fromAccount.balance -= amount;
  toAccount.balance += amount;
  
  const transaction = {
    id: `TXN${Date.now()}`,
    from,
    to,
    amount,
    timestamp: new Date().toISOString(),
    status: 'completed'
  };
  
  transactions.push(transaction);
  
  res.json({ success: true, transaction });
});

app.get('/api/transactions', (req, res) => {
  res.json({ total: transactions.length, transactions: transactions.slice(-100) });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Godmode Ultra v2.0 running on port ${PORT}`);
  console.log(`📊 Managing ${accounts.size} accounts`);
  console.log(`🏦 Monitoring ${Object.keys(vaults).length} vaults`);
});
